export const currentUser = {
  baseUrl: 'https://mesto.nomoreparties.co/v1/cohort-14/',
  headers: {
    authorization: '868762c3-88e2-4bf0-b9ab-a6e82ee7a617',
    'Content-Type': 'application/json',
  },
};